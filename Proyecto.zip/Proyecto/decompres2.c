/* Compresión de archivos usando el Algoritmo de Huffman: */
/* (C) Noviembre de 2000 Salvador Pozo Coronado           */
/* (C) Noviembre de 2018-2021 Mariano Ruiz (correcciones) */
/* Descompresor */

#include <stdio.h>
#include <stdlib.h>

/* Tipo nodo para árbol */
typedef struct _nodo
{
   unsigned char letra;           /* Letra a la que hace referencia el nodo */
   unsigned long int bits;        /* Valor de la codificación de la letra */
   char nbits;                    /* Número de bits de la codificación */
   struct _nodo *cero;            /* Puntero a la rama cero de un árbol */
   struct _nodo *uno;             /* Puntero a la rama uno de un árbol */
} tipoNodo;                       /* Nombre del tipo */

/* Funciones prototipo */
void BorrarArbol(tipoNodo *n);

// int main(int argc, char *argv[])
// {
   
// }

