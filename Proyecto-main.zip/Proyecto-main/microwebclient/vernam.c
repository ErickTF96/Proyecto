#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vernam.h"

//Prototipos de Funciones
int  main(int argc, char *argv[]){
	
	vernam("pp.txt",key,"pp2.txt");
	vernam("pp2.txt",key,"pp3.txt");
	printf("Cifrado terminado!!\n");
	return 0;
}


